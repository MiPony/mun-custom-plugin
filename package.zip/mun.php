<?php



/**
 * Plugin Name: MUN
 */
defined( 'ABSPATH' ) || exit;

include_once 'inc/autoload.php';
register_activation_hook( __FILE__, 'myplugin_install' );
function myplugin_install(){
    include_once 'inc/base.php';

}
use \mun\inc\form\Shortcode;
use mun\inc\REGISTRY;

new Shortcode();

if (!function_exists('write_log')) {

    function write_log($log) {
        if (true === WP_DEBUG) {
            if (is_array($log) || is_object($log)) {
                error_log(print_r($log, true));
            } else {
                error_log($log);
            }
        }
    }

}
//$CID,$date,$first_name,$last_name
//$job = new CreateJob(4250,'asdasd','Mike','Harbut');
//var_dump($job->add_job());
//$token = new JobToken(4250,'mharbut@me.com');
if( WP_DEBUG && WP_DEBUG_DISPLAY && (defined('DOING_AJAX') && DOING_AJAX) ){
    @ ini_set( 'display_errors', 1 );
}
//$sug = new GetDatesSuggestions();
//$dates = $sug->get_dates();
include_once 'inc/Ajax/AjaxCreateJob.php';
include_once 'inc/Ajax/AjaxGetOrgData.php';
include_once 'inc/Ajax/AjaxGetJobToken.php';
include_once 'inc/Ajax/AjaxGetDatesSuggestions.php';
include_once 'inc/Ajax/AjaxMailer.php';
add_filter( 'http_request_timeout', 'filter_function_name_4327', 10, 1);
function filter_function_name_4327( $timeout_value){
    $timeout_value = 20;
    return $timeout_value;
}
