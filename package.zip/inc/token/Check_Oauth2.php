<?php


namespace mun\inc\token;


class Check_Oauth2
{

    public static  function check()
 {
     $special_query_results = get_transient( 'Oauth2' );

     if ( false === $special_query_results ) {
         $Oauth2 = new Oauth2();
         set_transient( 'Oauth2', json_decode($Oauth2->result)->access_token,HOUR_IN_SECONDS );
     }

     return $special_query_results;
 }
}