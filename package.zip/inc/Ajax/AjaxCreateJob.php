<?php
use mun\inc\Api\CreateJob;
add_action( 'wp_ajax_createjob','createjob');
add_action( 'wp_ajax_nopriv_createjob' , 'createjob');

function createjob(){
//    $job = new CreateJob($_POST['date'])
//    var_dump(date("d-m-Y", strtotime($_POST['date'])));
    $job = new CreateJob($_POST['CID'],$_POST['date'],$_POST['first_name'],$_POST['last_name']);
    $result = $job->add_job();


    if (!empty($result)){
        wp_send_json_success($result);
    } else {
        wp_send_json_error($result);
    }
}

