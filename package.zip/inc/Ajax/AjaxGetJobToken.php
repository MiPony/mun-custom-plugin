<?php

use mun\inc\Api\JobToken;
add_action( 'wp_ajax_jobtoken','getjobtoken');
add_action( 'wp_ajax_nopriv_jobtoken' , 'getjobtoken');
function getjobtoken(){
    $jobtoken = new JobToken($_POST['CID'],$_POST['email'],$_POST['date_start']);
    $token = $jobtoken->get_job_token();
    $json = json_decode($token);
    if (!empty($json)){
        wp_send_json_success($token);
    } else {
        wp_send_json_error($token);
    }
}



