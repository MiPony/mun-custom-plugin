<?php
use \mun\inc\mail\Mailer;



add_action( 'wp_ajax_mailer','mailer_func');
add_action( 'wp_ajax_nopriv_mailer' , 'mailer_func');

function mailer_func(){
    $data = stripcslashes($_POST['data']);
    $json = json_decode($data);
    $array_from_json = (array) $json;
    $array_from_json = array_filter($array_from_json);
    $mailer = new Mailer($array_from_json);
    $mailer->renderMassage();
    $mailer->sendMail();
}