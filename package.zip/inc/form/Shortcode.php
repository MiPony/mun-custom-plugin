<?php
namespace mun\inc\form;

use mun\inc\Ajax\AjaxGetOrgData;
use mun\inc\REGISTRY;
use mun\inc\token\Check_Oauth2;
class Shortcode
{
    public function __construct()
    {
        add_shortcode( 'munform', array( $this, 'form' ) );
    }

    public function form()
    {
        Check_Oauth2::check();
        include(REGISTRY::PLUGIN_PATH. '/html/form.php');
        wp_enqueue_script('jq', plugins_url('/mun/inc').'/js/jq.js', array('mun'), 333 );
        wp_enqueue_script('validate', 'https://cdn.jsdelivr.net/npm/jquery-validation@1.19.3/dist/jquery.validate.min.js', array('jq'), 333 );
        wp_enqueue_script('additional', 'https://cdn.jsdelivr.net/npm/jquery-validation@1.19.3/dist/additional-methods.min.js', array('jq'), 333 );
        wp_enqueue_script('custom-validation', plugins_url('/mun/inc').'/js/validation.js', array('validate'), 333 );
        wp_enqueue_script('mun', plugins_url('/mun/inc').'/js/main.js', array(), 333 );
        wp_enqueue_script('fields', plugins_url('/mun/inc').'/js/fields.js', array('mun'), 333 );
        wp_enqueue_style('mun', plugins_url('/mun/inc').'/css/style.css', array(), 333 );
        wp_localize_script( 'mun', 'mainVars', array(
            'ajax_url' => admin_url('admin-ajax.php'),
            'nonce' => wp_create_nonce('ajax-nonce')
        ) );

    }

}