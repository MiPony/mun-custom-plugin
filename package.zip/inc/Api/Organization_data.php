<?php
namespace mun\inc\Api;

use mun\inc\REGISTRY;
use mun\inc\token\Check_Oauth2;


class Organization_data
{
    public $result;
    public function __construct(Organization $organization)
    {
        $response = wp_remote_get(REGISTRY::BASIC_URL .
            REGISTRY::ORGANIZATION_DATA_URL .
            $organization->cid .
            '?email=' . $organization->email,
            array('headers' => array('Authorization' => 'Bearer '. Check_Oauth2::check()) ));
        if ( is_wp_error( $response ) ){
            echo $response->get_error_message();
            $this->result = $response;
        }
        elseif( wp_remote_retrieve_response_code( $response ) === 200 ){
            $this->result = wp_remote_retrieve_body( $response );
        }
        return $this->result;
    }
}