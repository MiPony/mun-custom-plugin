<?php


namespace mun\inc\Api;


use mun\inc\REGISTRY;
use mun\inc\token\Check_Oauth2;

class CreateJob
{
    public $CID;
    public $date;
    public $first_name;
    public $last_name;
    public $result;
    public function __construct($CID,$date,$first_name,$last_name)
    {
        $this->CID = $CID;
        $this->date = date("d-m-Y", strtotime($date));
        $this->first_name = $first_name;
        $this->last_name = $last_name;

    }
    public function add_job (){
        $body = array();
        $body['company_id']=$this->CID;
        $body['first_name']=$this->first_name;
        $body['last_name']=$this->last_name;
        $body['date'] = $this->date;

        $response = wp_remote_post(REGISTRY::BASIC_URL. REGISTRY::CREATE_WO_URL, array(
            'headers'=> array('Authorization' => 'Bearer '. Check_Oauth2::check(),'Content-Type' =>'application/json'),
            'timeout ' => array(10),
            'body' => json_encode($body)));
//        if ( is_wp_error( $response ) ){
//            $$this->result->get_error_message();
//        }
        write_log('Create order');
        write_log($body);
        write_log('Create order response');
        write_log($response);
        write_log('Create order response code');
       write_log(wp_remote_retrieve_response_code( $response ));
        write_log('Create order response body');
        write_log(wp_remote_retrieve_body( $response ));
        if( wp_remote_retrieve_response_code( $response ) === 200 ){
            $this->result = json_decode(wp_remote_retrieve_body( $response ));
        }
        return $this->result;
    }
}