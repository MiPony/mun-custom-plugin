<?php
    namespace mun\inc\mail;

class Mailer
{
    public $body;
    public $result;
    public $mails;
    public $message;
    public $subject;
    public $headers;
    public function __construct($body)
    {
        $this->body = $body;
        $this->mails = ['support@falcogroups.com','info@municipalbackflow.com'];
        $this->subject = 'Schedule a Backflow Test Request submitted by ';
        $this->headers = array(
            'From:  <falcogroups.com>',
            'content-type: text/html',
        );
    }
    public function sendToCommercial(){
        foreach ($this->mails as $mail){
            wp_mail($mail,$this->subject,$this->message,$this->headers);
        }
    }
    public function sendToResidential(){
        foreach ($this->mails as $mail){
            wp_mail($mail,$this->subject,$this->message,$this->headers);
        }
    }
    public function renderMassage(){
        foreach ($this->body as $key => $value){
            $this->message = $this->message. '<p>'.$key.' = '.$value.'</p><br>';
        }
    }
    public function sendMail(){
//        $this->body['type'] == 'commercial' ? $this->sendToCommercial() : $this->sendToResidential();
        return $this->message;
    }
}