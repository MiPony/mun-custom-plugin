<form id="residential_third_section" name="residential_third_section" style="display: none">
    <section>
        <div class="hide-if-success">
            <legend>
                IS THIS A GATED COMMUNITY?*
            </legend>
            <div>
                <input type="radio" id="gatedChoice1"
                       data-radio="gated"
                       name="gated" value="yes">
                <label for="gatedChoice1">YES</label>

                <input type="radio" id="gatedChoice2"
                       data-radio="gated"
                       name="gated" value="no">
                <label for="gatedChoice2">NO</label>
                <div class="hide" data-group="gated">
                    <legend>
                        PLEASE ADD GATE INSTRUCTIONS FOR THE TECHNICIAN BELOW.*
                    </legend>
                    <input type="textarea"  data-el="gated" name="gated_text">
                </div>
            </div>
            <legend>
                THE SITE ADDRESS IS: *
            </legend>
            <div>
                <input type="radio" id="adressTypeChoice1"
                       data-radio="rental_radio"
                       name="adress_type" value="owner">
                <label for="adressTypeChoice1">OWNER OCCUPIED</label>

                <input type="radio" id="adressTypeChoice2"
                       data-radio="rental_radio"
                       name="adress_type" value="rental">
                <label for="adressTypeChoice2">A RENTAL</label>

                <input type="radio" id="adressTypeChoice3"
                       data-radio="rental_radio"
                       name="adress_type" value="vacant">
                <label for="adressTypeChoice3">VACANT</label>
            </div>
            <div data-group="rental_radio" class="hide">
                <div>
                    <legend>RENTAL TENANT NAME:*</legend>
                    <input type="text" data-el="rental_radio" name="rental_first_name">
                    <p>FIRST</p>
                    <input type="text" data-el="rental_radio" name="rental_last_name">
                    <p>LAST</p>
                </div>
                <legend>
                    RENTAL TENANT PHONE:*
                </legend>
                <input type="text" data-el="rental_radio" name="rental_phone">
                <legend>
                    RENTAL TENANT EMAIL*
                </legend>
                <input type="email" data-el="rental_radio" name="rental_email">
                <p>This is required if tenant will be receiving scheduling updates.</p>
            </div>
            <div data-group="vacant_radio" class='hide'>
                <legend>
                    HOW WILL THE TECHNICIAN GAIN ACCESS TO THE SITE / BACKFLOW DEVICES?*
                </legend>
                <div>
                    <input type="radio" id="accessTypeChoice1"
                           data-el="vacant_radio" data-radio="lockbox_radio"
                           name="access_type" value="contact">
                    <label for="accessTypeChoice1">SITE CONTACT</label>

                    <input type="radio" id="accessTypeChoice2"
                           data-el="vacant_radio" data-radio="lockbox_radio"
                           name="access_type" value="lockbox">
                    <label for="accessTypeChoice2">LOCKBOX ONSITE</label>
                </div>
                <div data-group="lockbox_access" class="hide">
                    <legend>
                        DESCRIBE LOCATION OF LOCKBOX?*
                    </legend>
                    <input type="textarea" data-el="lockbox_access" name="lockbox_location">
                    <legend>
                        LOCKBOX CODE:*
                    </legend>
                    <input type="email" data-el="lockbox_access"  name="lockbox_code">
                </div>
            </div>
        </div>
        <legend>
            IS THIS FOR YOUR LAWN IRRIGATION / LAWN SPRINKLERS?*
        </legend>
        <div>
            <input type="radio" data-radio="sprinklers_type" id="accessTypeChoice1"
                   name="lawn" value="yes">
            <label for="accessTypeChoice1">YES</label>
            <input type="radio" data-radio="sprinklers_type" id="accessTypeChoice2"
                   name="lawn" value="no" >
            <label for="accessTypeChoice2" >NO</label>
            <input type="radio" data-radio="sprinklers_type" id="accessTypeChoice3"
                   name="lawn" value="not_sure">
            <label for="accessTypeChoice3" >NOT SURE?</label>
        </div>
        <div data-group="sprinklers_group" class="hide">
            <legend>
                DEVICE LOCATION?*
            </legend>
            <div>
                <input type="radio" id="deviseLocationChoice1"
                       data-radio="inside_radio"
                       data-el="sprinklers_inputs"
                       name="device_location" value="inside">
                <label for="deviseLocationChoice1">INSIDE RESIDENCE</label>
                <input type="radio" id="deviseLocationChoice2"
                       data-el="sprinklers_inputs"
                       data-radio="inside_radio"
                       name="device_location" value="outside">
                <label for="deviseLocationChoice2">OUTSIDE RESIDENCE</label>
                <input type="radio" id="deviseLocationChoice3"
                       data-el="sprinklers_inputs"
                       data-radio="inside_radio"
                       name="device_location" value="not_sure">
                <label for="deviseLocationChoice3">NOT SURE?</label>
            </div>
        </div>
        <div data-group="inside_location" class="hide">
            <legend>
                PLEASE CHOOSE THE EARLIEST DATE THAT YOU OR YOUR IRRIGATION COMPANY WILL HAVE THE BACKFLOW DEVICE(S) INSTALLED AND WATER TURNED ON BY.*
            </legend>
            <input type="date" data-el="inside_location" name="turned_on">
        </div>
    </section>
    <button type="button" data-button='prev'>
        Previous
    </button>
    <button type="submit" id ='next'>
        NEXT
    </button>
</form>