    <form name="comment_form" id="comment_form" style="display: none">
        <legend>ADDITIONAL COMMENT(S) OR QUESTION(S):</legend>
        <input type="textarea" name="comment" placeholder="I would like to schedule a Backflow Test...">
        <button type='button' data-button ='prev' id="editing_prev">
            Previous
        </button>
        <button type='submit'>
            Submit
        </button>
    </form>
</div>