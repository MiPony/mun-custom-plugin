<form id ='datesForm'>
    <input type="date" name="StartDate">
    <input type="date" name="StartDate">
    <input type="time" name="time">

</form>



