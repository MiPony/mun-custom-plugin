 <?php
    use mun\inc\REGISTRY;
?>


<?php
    include(REGISTRY::PLUGIN_PATH. '/html/both_first_section.php');
    include(REGISTRY::PLUGIN_PATH. '/html/сommercial_second_section.php');
    include(REGISTRY::PLUGIN_PATH. '/html/residential_second_section.php');
    include(REGISTRY::PLUGIN_PATH. '/html/commercial_third_section.php');
    include(REGISTRY::PLUGIN_PATH. '/html/residential_third_section.php');
    include(REGISTRY::PLUGIN_PATH. '/html/fourth_section.php');
    include(REGISTRY::PLUGIN_PATH. '/html/fifth_section.php');
    include(REGISTRY::PLUGIN_PATH. '/html/sixth_step.php');
    include(REGISTRY::PLUGIN_PATH. '/html/comment_form.php');
    ?>

