<div class="munform">


<form id="firstForm" name="firstForm">
    <div class="first__section">

        <legend>
            IS THE BACKFLOW ASSEMBLY LOCATED AT A COMMERCIAL OR RESIDENTIAL PROPERTY?
        </legend>
        <div class="radio__btn">
            <input type="radio" id="typeChoice1"
                name="type" checked  required value="commercial">
            <label for="typeChoice1">Commercial</label>
            <input type="radio" id="typeChoice2"
                name="type" value="residential">
            <label for="typeChoice2">Residential</label>
        </div>
        <div>
            <p>CID:</p>
            <input type="text"  id='CID' name ='CID' value='425'>
            <p>EMAIL:</p>
            <input type="email"  id='email' name ='email' value='mharbut@me.com'>
            <button type="submit" id ='sendOrganization' >Submit</button>
        </div>
    </div>
</form>
<div class="edit_box">


</div>