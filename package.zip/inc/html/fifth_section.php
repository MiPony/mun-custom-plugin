<form name="fifth_form" id ='fifth_form' style="display: none">
    <h2>Select date:</h2>
    <div class="suggestions">

    </div>
    <button type="button" id="nextDate"> Next date </button>
    <button type='button' data-button = 'prev'>
        Previous
    </button>
    <button type='submit'>
        Next
    </button>
</form>