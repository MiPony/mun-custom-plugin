<form name="sixth_form" style="display:none"></form>
    <div class="success" style="display:none">
        Success create work order
    </div>
