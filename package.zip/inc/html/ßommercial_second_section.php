
<form id="commercial_second_form" name="commercial_second_form" style="display: none">
    <section>
        <legend>CID # (CUSTOMER IDENTIFICATION NUMBER)</legend>
        <input type="text"  name ='CID'>
        <p>If you retrieved a correspondence letter from us, enter your CID# (Customer Identification Number) located at the top right corner.</p>
        <legend>CCN # OR SITE ID #</legend>
        <input type="text" required name ='CCN'>
        <p>Often provided by your City or Village.</p>
        <legend>NAME:*</legend>
        <div class="form__name">
            <input type="text" required name ='first_name'>
            <p>FIRST</p>
            <input type="text" required name ='second_name'>
            <p>LAST</p>
        </div>
        <legend>EMAIL:*</legend>
        <input type="email" required name ='email'>
        <p>If you can not provide a valid email address at this time, please call the office (312) 638-9878 to schedule.</p>
        <legend>PHONE:*</legend>
        <input type="text" required name ='phone'>
        <legend class="hide phone__legend">
            IS (068) 904-1882 YOUR MOBILE, HOME OR WORK NUMBER?*
        </legend>
        <div class="hide phone__div">
            <input type="radio" id="typeChoice1"
                   data-radio="phone_type_c"
                   name="phone_type" value="mobile">
            <label for="typeChoice1">MOBILE</label>

            <input type="radio" id="typeChoice2"
                   data-radio="phone_type_c"
                   name="phone_type" value="home">
            <label for="typeChoice2">HOME</label>

            <input type="radio" id="typeChoice3"
                   data-radio="phone_type_c"
                   name="phone_type" value="work">
            <label for="typeChoice3">WORK</label>
            <input type="radio" id="typeChoice4"
                   data-radio="phone_type_c"
                   name="phone_type" value="other">
            <label for="typeChoice4">OTHER</label>
            <div data-group="phone_group_c" class ='hide'>
                <input  data-required='false' data-el="other_group_c" type="text" name="other">
            </div>
        </div>
        <div class="hide-if-success hide contact__updates">
            <legend class="contact__text">WILL TEST TEST BE THE SITE CONTACT FOR THE SCHEDULING / UPDATES?*</legend>
            <div>
                <input type="radio" id="siteContact1"
                       data-radio="contact_update"
                       name="contact_update" value="YES">
                <label for="contactChoice1">YES</label>

                <input type="radio" id="siteContact2"
                       data-radio="contact_update"
                       name="contact_update" value="NO">
                <label for="contactChoice2">NO</label>

            </div>
        </div>
        <div class="hide-if-success hide" data-group="contact_update">
            <div class="form__line">
            </div>
            <div>
                <legend>SITE CONTACT NAME:*</legend>
                <input type="text" data-el="contact_update" name="site_first_name">
                <p>FIRST</p>
                <input type="text" data-el="contact_update" name="site_last_name">
                <p>LAST</p>
            </div>
            <legend>
                SITE CONTACT PHONE #*
            </legend>
            <input type="text" name="site_phone" data-el="contact_update">
            <legend>
                SITE CONTACT EMAIL*
            </legend>
            <input type="email" name="site_email" data-el="contact_update">

        </div>
        <button type="button" data-button='prev'>
            Previous
        </button>
        <button type="submit" id ='next'>
            NEXT
        </button>
    </section>
</form>