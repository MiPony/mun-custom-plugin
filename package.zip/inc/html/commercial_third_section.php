
<form id="commercial_third_section" name="commercial_third_section" style="display:none">
    <legend>COMPANY OR BUSINESS NAME:*</legend>
    <input type="text" required name='company_name'>
    <div class="hide-if-success">
        <legend>IS THE WORK AT TEST TO BE PERFORMED SUBJECT TO PREVAILING WAGE?*</legend>
        <div>
            <input type="radio" id="wageChoice1"
                   name="wage" value="yes" checked>
            <label for="wageChoice1">yes</label>

            <input type="radio" id="wageChoice2"
                   name="wage" value="no">
            <label for="wageChoice2">no</label>
        </div>
    </div>
    <legend>
        SITE ADDRESS OF BACKFLOW ASSEMBLY / DEVICE(S) FOR TESTING:*
    </legend>
    <input type="text" name="address">
    <p>STREET ADDRESS</p>
    <input type="text" name="address_line">
    <p>ADDRESS LINE 2</p>
    <div>
        <input type="text" name="city">
        <p>CITY</p>
        <select name="state" id="state">
            <option value="illinois">Illinois</option>
        </select>
        <p>STATE</p>
        <input type="text" name="zip">
        <p>ZIP CODE</p>
    </div>
    <legend>
        IS THE MAILING AND BILLING ADDRESS THE SAME AS THE SITE ADDRESS ENTERED ABOVE?*
    </legend>
    <div>
        <input type="radio" id="addressChoice1"
               data-radio="mailing_billing_c"
               name="mailing_billing" value="yes">
        <label for="addressChoice1">yes</label>

        <input type="radio" id="addressChoice2"
               data-radio="mailing_billing_c"
               name="mailing_billing" value="no">
        <label for="addressChoice2">no</label>
    </div>
    <div class="hide-if-success" >
        <legend>
            DO YOU USE A THIRD PARTY BILLING COMPANY?*
        </legend>
        <div>
            <input type="radio"
                   data-radio="third_party"
                   id="thirdPartyChoice1"
                   name="third_party" value="yes">
            <label for="thirdPartyChoice1">yes</label>

            <input type="radio"
                   data-radio="third_party"
                   id="thirdPartyChoice2"
                   name="third_party" value="no">
            <label for="thirdPartyChoice2">no</label>
            <div class="third_party hide" data-group="third_party">
                <input type="text" data-el="third_party" name="third_party_name">
                <p>Example: Vendor Cafe or Real Page</p>
            </div>
        </div>
    </div>


    <legend>
       date
    </legend>
    <input type="date" name="turned_on">

    <div class="hide-if-success">
        <legend>
            THE SITE ADDRESS IS: *
        </legend>
        <div>
            <input type="radio" id="adressTypeChoice1"
                   data-radio="adress_is"
                   name="adress_type" value="owner">
            <label for="adressTypeChoice1">OWNER OCCUPIED</label>

            <input type="radio" id="adressTypeChoice2"
                   data-radio="adress_is"
                   name="adress_type" value="rental">
            <label for="adressTypeChoice2">A RENTAL</label>

            <input type="radio" id="adressTypeChoice3"
                   data-radio="adress_is"
                   name="adress_type" value="vacant">
            <label for="adressTypeChoice3">VACANT</label>
        </div>
    </div>
    <div class="mailing_billing_c hide" data-group="mailing_billing_c">
        <div class="billing">
            <legend>
                BILLING ATTENTION TO:*
            </legend>
            <p>ATTENTION: BOB SMITH: COMPANY OR BUSINESS NAME</p>
            <input type="text" data-el="mailing_billing_c" name="billing_attention">
            <input type="text" data-el="mailing_billing_c" name="billing_address">
            <p>STREET ADDRESS</p>
            <input type="text" data-el="mailing_billing_c" name="billing_address_line">
            <p>ADDRESS LINE 2</p>
            <div>
                <input type="text" data-el="mailing_billing_c" name="billing_city">
                <p>CITY</p>
                <select name="billing_state" data-el="mailing_billing_c" id="state">
                    <option value="illinois">Illinois</option>
                </select>
                <p>STATE</p>
                <input type="text" data-el="mailing_billing_c" name="billing_zip">
                <p>ZIP CODE</p>
            </div>
        </div>
        <div class="mailing">
            <legend>
                MAILING ATTENTION TO:*
            </legend>
            <p>ATTENTION: BOB SMITH: COMPANY OR BUSINESS NAME</p>
            <input type="text" name="mailing_attention" data-el="mailing_billing_c">
            <input type="text" name="mailing_address" data-el="mailing_billing_c">
            <p>STREET ADDRESS</p>
            <input type="text" name="mailing_address_line" data-el="mailing_billing_c">
            <p>ADDRESS LINE 2</p>
            <div>
                <input type="text" name="mailing_city" data-el="mailing_billing_c">
                <p>CITY</p>
                <select name="mailing_state" id="state" data-el="mailing_billing_c">
                    <option value="illinois">Illinois</option>
                </select>
                <p>STATE</p>
                <input type="text" name="mailing_zip" data-el="mailing_billing_c">
                <p>ZIP CODE</p>
            </div>
        </div>
    </div>
    <div data-group="rental" class="hide-if-success hide">
        <div class="">
            <legend>RENTAL TENANT NAME:*</legend>
            <input type="text" data-el="rental" name="rental_first_name">
            <p>FIRST</p>
            <input type="text" data-el="rental" name="rental_last_name">
            <p>LAST</p>
        </div>
        <legend>
            RENTAL TENANT PHONE:*
        </legend>
        <input type="text" data-el="rental" name="rental_phone">
        <legend>
            RENTAL TENANT EMAIL*
        </legend>
        <input type="email"  data-el="rental" name="rental_email">
        <p>This is required if tenant will be receiving scheduling updates.</p>
    </div>
    <div class="hide-if-success hide" data-group="vacant">
        <legend>
            HOW WILL THE TECHNICIAN GAIN ACCESS TO THE SITE / BACKFLOW DEVICES?*
        </legend>
        <div>
            <input type="radio" id="accessTypeChoice1"
                   data-el="vacant"
                   data-radio="contact_site"
                   name="access_type" value="contact" >
            <label for="accessTypeChoice1">SITE CONTACT</label>

            <input type="radio" id="accessTypeChoice2"
                   data-el="vacant"
                   data-radio="contact_site"
                   name="access_type" value="lockbox">
            <label for="accessTypeChoice2">LOCKBOX ONSITE</label>
        </div>
        <div data-group="contact_site" class="hide">
            <legend>
                DESCRIBE LOCATION OF LOCKBOX?*
            </legend>
            <input type="textarea" data-el="contact_site" name="lockbox_location">
            <legend>
                LOCKBOX CODE:*
            </legend>
            <input type="email" data-el="contact_site" name="lockbox_code">
        </div>
    </div>
    <button type="button" data-button='prev'>
        Previous
    </button>
    <button type="submit" id ='next'>
        NEXT
    </button>
</form>