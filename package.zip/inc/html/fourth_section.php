<form id ='fourthForm' name='fourthForm' style='display:none'>
    
<div class="fourth__section">
<!--        ADDITIONAL COMMENT(S) OR QUESTION(S):-->
<!--        <input type="area" placeholder="I would like to schedule a Backflow Test...">-->
    <h2>Devices:</h2>
    <table id="device_table">
    </table>
    <h2>Fees:</h2>
    <table id="fees_table">

    </table>

<div class="buttons">
    <button type='button' data-button ='prev' id="editing_prev">
        Previous
    </button>
    <button type='submit' value=" Next">
        Next
    </button>

</div>
</div>
</form>
