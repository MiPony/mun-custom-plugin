<?php
use \mun\inc\REGISTRY;
?>
<form id="residential_second_form" name="residential_second_form" style="display:none">
    <legend data-show="a">CID # (CUSTOMER IDENTIFICATION NUMBER)</legend>
    <input type="text"  required name ='CID'>
    <p>If you retrieved a correspondence letter from us, enter your CID# (Customer Identification Number) located at the top right corner.</p>
    <legend>CCN # OR SITE ID #</legend>
    <input type="text" required name ='CCN'>
    <p>Often provided by your City or Village.</p>
    <legend>NAME:*</legend>
    <div class="form__name">
        <input type="text" required name ='first_name'>
        <p>FIRST</p>
        <input type="text" required name ='second_name'>
        <p>LAST</p>
    </div>
    <legend>EMAIL:*</legend>
    <input type="email" required name ='email'>
    <p>If you can not provide a valid email address at this time, please call the office (312) 638-9878 to schedule.</p>
    <legend>PHONE:*</legend>
    <input type="text" required name ='phone'>
    <div class="phone__div hide">
        <legend class="phone__legend hide">
            IS (068) 904-1882 YOUR MOBILE, HOME OR WORK NUMBER?*
        </legend>
        <div >
            <input type="radio" data-radio="phone_type" id="typeChoice1"
                   name="phone_type" value="mobile">
            <label for="typeChoice1">MOBILE</label>

            <input type="radio" data-radio="phone_type" id="typeChoice2"
                   name="phone_type" value="home">
            <label for="typeChoice2">HOME</label>

            <input type="radio" data-radio="phone_type" id="typeChoice3"
                   name="phone_type" value="work">
            <label for="typeChoice3">WORK</label>
            <input type="radio" data-radio="phone_type" id="typeChoice4"
                   name="phone_type" value="other">
            <label  for="typeChoice4">OTHER</label>
            <div data-group="phone_type" class="hide">
                <input data-required='false' data-el="phone_type" type="text" name="other">
            </div>

        </div>
    </div>

    <legend>
        RESIDENTIAL SITE ADDRESS:*
    </legend>
    <input type="text" name="address">
    <p>STREET ADDRESS</p>
    <input type="text" name="address_line">
    <p>ADDRESS LINE 2</p>
    <div>
        <input type="text" name="city">
        <p>CITY</p>
        <select name="state" id="state">
            <?php  foreach (REGISTRY::STATES as $key => $value):
                if ($key == 'IL'):?>
                    <option value="<?php echo $key ?>" selected><?php echo $value ?></option>
                <?php else: ?>
                    <option value="<?php echo $key ?>"><?php  echo $value ?></option>
            <?php endif;
            endforeach; ?>
        </select>
        <p>STATE</p>
        <input type="text" name="zip">
        <p>ZIP CODE</p>
    </div>
    <div class ='contact__updates'>
        <legend>
            IS THE MAILING AND BILLING ADDRESS THE SAME AS THE SITE ADDRESS ENTERED ABOVE?*
        </legend>
        <div>
            <input type="radio" data-radio="mailing_billing" id="addressChoice1"
                   name="mailing_billing" value="yes">
            <label for="addressChoice1">yes</label>

            <input type="radio" data-radio="mailing_billing" id="addressChoice2"
                   name="mailing_billing" value="no">
            <label for="addressChoice2">no</label>
        </div>
    </div>
    <div class="hide" data-group="mailing_billing">
        <div class="hide-if-success">
            <legend>
                BILLING /MAILING ATTENTION TO:*
            </legend>
            <input  data-el="mailing_billing_group" type="text" data-required='true' name="bill_mail_name">
            <p>ATTENTION: BOB SMITH: COMPANY OR BUSINESS NAME</p>
        </div>
        <legend>
            BILLING /MAILING ADDRESS:*
        </legend>
        <input type="text" data-required='true' data-el="mailing_billing_group" name="bill_mail_address">
        <p>STREET ADDRESS</p>
        <input type="text" data-required='false' data-el="mailing_billing_group" name="bill_mail_address_line">
        <p>ADDRESS LINE 2</p>
        <div>
            <input type="text" data-required='true' data-el="mailing_billing_group"  name="bill_mail_city">
            <p>CITY</p>
            <select name="state" id="bill_mail_state">
                <?php  foreach (REGISTRY::STATES as $key => $value):
                    if ($key == 'IL'):?>
                        <option value="<?php echo $key ?>" selected><?php echo $value ?></option>
                    <?php else: ?>
                        <option value="<?php echo $key ?>"><?php  echo $value ?></option>
                    <?php endif;
                endforeach; ?>
            </select>
            <p>STATE</p>
            <input type="text" data-required='true' data-el="mailing_billing_group"  name="bill_mail_zip">
            <p>ZIP CODE</p>
    </div>
    </div>
    <div class="contact__updates-div hide">
        <legend class="contact__mailing">
            WILL ASDAS DASDASD BE THE CONTACT FOR SCHEDULING / UPDATES?*
        </legend>
        <div>
            <input type="radio" data-radio="site_contact" id="siteChoice1"
                   name="site_choice" value="yes">
            <label for="siteChoice1">yes</label>

            <input type="radio" data-radio="site_contact" id="siteChoice2"
                   name="site_choice" value="no">
            <label for="siteChoice2">no</label>
        </div>
    </div>
    <div class="site_contact hide" data-group="site_contact">
        <legend>SITE CONTACT NAME:*</legend>
        <div class="form__name">
            <input type="text" data-el="site_contact"  name='site_contact_first'>
            <p>FIRST</p>
            <input type="text" data-el="site_contact"  name='site_contact_last'>
            <p>LAST</p>
        </div>
        <legend>SITE CONTACT PHONE #*</legend>
            <input type="text" data-el="site_contact"  name='site_contact_phone'>
        <legend>SITE CONTACT EMAIL*</legend>
            <input type="email" data-el="site_contact"  name='site_contact_email'>
    </div>
    <button type="button" data-button='prev'>
        Previous
    </button>
    <button type="submit" id ='next'>
        NEXT
    </button>
</form>