<form id='thirdForm' style='display:none'>
<legend>Choose device:</legend>
       <div class="third__section">
              <select name="device" id="device"></select>
       </div>
</form>