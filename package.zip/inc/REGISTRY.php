<?php
namespace mun\inc;



class REGISTRY {

    const BASIC_URL = 'http://dev.municipalbackflowllc.com';
    const BASIC_AUTH_URL = '/session/token';
    const OAUTH2_URL = '/oauth/token';
    const CLIENT_ID = '4549b57d-4caf-4468-8847-b365ab4f0f61';
    const CLIENT_SECRET = '3WWknwVTXVKMSCkHuoWwzWWzb9zGmBRV';
    const ORGANIZATION_DATA_URL = '/api/public-site/organization-data/';
    const WO_SCHEDULE_START_URL = '/api/public-site/wo-schedule/start';
    const WO_DATES_SUGGESTIONS_URL = '/api/public-site/wo-schedule/';
    const CREATE_WO_URL = '/api/public-site/create-wo';
    const USER = 'Public site';
    const PSWD = 'Uu~8[HrcqX';
    const PLUGIN_PATH = __DIR__;
    const STATES = array (  "AL"=>"Alabama",
                            "AK"=> "Alaska",
                            "AS"=> "American Samoa",
                            "AZ"=> "Arizona",
                            "AR"=> "Arkansas",
                            "CA"=> "California",
                            "CO" => "Colorado",
                            "CT"=> "Connecticut",
                            "DE"=> "Delaware",
                            "DC"=> "District Of Columbia",
                            "FM"=> "Federated States Of Micronesia",
                            "FL"=> "Florida",
                            "GA"=> "Georgia",
                            "GU"=> "Guam",
                            "HI"=> "Hawaii",
                            "ID"=> "Idaho",
                            "IL"=> "Illinois",
                            "IN"=> "Indiana",
                            "IA"=> "Iowa",
                            "KS"=> "Kansas",
                            "KY"=> "Kentucky",
                            "LA"=> "Louisiana",
                            "ME"=> "Maine",
                            "MH"=> "Marshall Islands",
                            "MD"=> "Maryland",
                            "MA"=> "Massachusetts",
                            "MI"=> "Michigan",
                            "MN"=> "Minnesota",
                            "MS"=> "Mississippi",
                            "MO"=> "Missouri",
                            "MT"=> "Montana",
                            "NE"=> "Nebraska",
                            "NV"=> "Nevada",
                            "NH"=> "New Hampshire",
                            "NJ"=> "New Jersey",
                            "NM"=> "New Mexico",
                            "NY"=> "New York",
                            "NC"=> "North Carolina",
                            "ND"=> "North Dakota",
                            "MP"=> "Northern Mariana Islands",
                            "OH"=> "Ohio",
                            "OK"=> "Oklahoma",
                            "OR"=> "Oregon",
                            "PW"=> "Palau",
                            "PA"=> "Pennsylvania",
                            "PR"=> "Puerto Rico",
                            "RI"=> "Rhode Island",
                            "SC"=> "South Carolina",
                            "SD"=> "South Dakota",
                            "TN"=> "Tennessee",
                            "TX"=> "Texas",
                            "UT"=> "Utah",
                            "VT"=> "Vermont",
                            "VI"=> "Virgin Islands",
                            "VA"=> "Virginia",
                            "WA"=> "Washington",
                            "WV"=> "West Virginia",
                            "WI"=> "Wisconsin",
                            "WY"=> "Wyoming"
                        );
}

