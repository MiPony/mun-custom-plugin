window.addEventListener('load',()=>{
    phoneChange()
    fullnameEvents()
    commercialSecondStep()
    commercialThirdStep()
    addEditingBlock()
    // contactScheduling()
    var newData,typeOfCompany ;
})
document.firstForm.addEventListener('submit',(e)=>{
    e.preventDefault()
    // catchPreviousForm()
})
function phoneChange (){
    let phoneInputs = document.getElementsByName('phone'),
        phoneDivs = document.querySelectorAll('.phone__div'),
        phoneLegends = document.querySelectorAll('.phone__legend');
        phoneInputs.forEach((input,index) => {
            input.addEventListener('input',()=>{
                phoneDivs.item(index).classList.remove('hide')
                phoneLegends.item(index).classList.remove('hide')
                phoneLegends.item(index).innerHTML = `IS ${input.value} YOUR MOBILE, HOME OR WORK NUMBER?*`
            })
        })
}
function fullnameEvents (){
    let firstNameInputs = document.getElementsByName('first_name'),
        lastNameInputs = document.getElementsByName('second_name');
    firstNameInputs.forEach((elem,index)=>{
        elem.addEventListener('input',()=>{
            lastNameInputs[index].addEventListener('input',()=>{
                fullnameChange(elem,lastNameInputs[index],index)
            })
        })
    })
    lastNameInputs.forEach((elem,index)=>{
        elem.addEventListener('input',()=>{
            firstNameInputs[index].addEventListener('input',()=>{
                fullnameChange(firstNameInputs[index],elem,index)
            })
        })
    })
}
function fullnameChange (firstName,lastName,index){
    let divForInputs = document.querySelectorAll('.contact__updates'),
        legend = document.querySelector('.contact__text'),
        div = document.querySelector('.contact__updates-div'),
        mail = document.querySelector('.contact__mailing');
    divForInputs.item(index).classList.remove('hide');
    if (index == 0){
        divForInputs.item(index).classList.remove('hide')
        if (divForInputs.item(index).style.display == 'none'){
            divForInputs.item(index).style.display = 'block'
        }
        legend.innerHTML = `WILL ${firstName.value} ${lastName.value} BE THE SITE CONTACT FOR THE SCHEDULING / UPDATES?*`
    } else {
        mail.classList.remove('hide')
        div.classList.remove('hide')
        mail.innerHTML = `WILL ${firstName.value} ${lastName.value} BE THE SITE CONTACT FOR THE SCHEDULING / UPDATES?*`;
    }
}
    function commercialSecondStep(){
    let secondForm = document.commercial_second_form;
    secondForm.addEventListener('submit',(e)=>{
        e.preventDefault()
        if (window.company == undefined){
            secondForm.style.display='none'
            document.commercial_third_section.style.display='block';
        }
    })
}
function commercialThirdStep(){
    let thirdForm = document.commercial_third_section;
    thirdForm.addEventListener('submit',(e)=>{
        console.log('asdasdasd',window.company,window.editing)
        e.preventDefault()
        if (window.company == undefined && window.editing == undefined){

            thirdForm.style.display = 'none';
            document.comment_form.style.display = 'block'
        } else if (window.company == undefined && window.editing == true){

            thirdForm.style.display='none'
            document.comment_form.style.display='block';
        }
    })
}
function contentForm(){
    let form = document.comment_form;
    form.addEventListener('submit',(e)=>{
        e.preventDefault()
        if (window.company == undefined && window.editing == false){
            let data = Object.fromEntries(new FormData(form).entries())
            console.log('last step')
        }
    })
}
contentForm()
function prevButton (){


    let prevBtns = document.querySelectorAll('[data-button^=prev]');
    prevBtns.forEach(elem =>{
        elem.addEventListener('click',()=>{
            catchPreviousForm(elem)
        })
    })
}
prevButton()
function catchPreviousForm(elem){
    let com_forms = [
            document.firstForm,
            document.commercial_second_form,
            document.commercial_third_section,
            document.comment_form
        ],
        res_forms = [
            document.firstForm,
            document.residential_second_form,
            document.residential_third_section,
            document.comment_form,
        ],index;
    if (firstFormData.type == 'commercial' && window.company == undefined){
        index = com_forms.indexOf(elem.closest('form'))
        com_forms[index].style.display = 'none'
        com_forms[index-1].style.display = 'block'
    } else if (firstFormData.type == 'residential' && window.company == undefined) {
        index = res_forms.indexOf(elem.closest('form'))
        res_forms[index].style.display = 'none'
        res_forms[index-1].style.display = 'block'
    }
}

function residentialSecondStep (){
    let form = document.residential_second_form;
    form.addEventListener('submit',(e)=>{
        e.preventDefault()
        if (window.company == undefined){
            form.style.display='none'
            document.residential_third_section.style.display='block';
        }
    })
}
residentialSecondStep()
function contactScheduling(){
    let firstName = document.getElementsByName('first_name')[1],
        lastName = document.getElementsByName('second_name')[1],
        legendText = document.getElementById('contact__mailing');
    firstName.addEventListener('input',()=>{
        lastName.addEventListener('input',()=>{
            legendText.innerHTML = `WILL ${firstName.value} ${lastName.value} BE THE CONTACT FOR SCHEDULING / UPDATES?*`
        })
    })
    lastName.addEventListener('input',()=>{
        firstName.addEventListener('input',()=>{
            legendText.innerHTML = `WILL ${firstName.value} ${lastName.value} BE THE CONTACT FOR SCHEDULING / UPDATES?*`
        })
    })
}
function submitThirdStep(){
    let form = document.residential_third_section;
    form.addEventListener('submit',(e)=>{
        e.preventDefault()
        console.log('asdasdasd',window.company,window.editing)
        if (window.company == undefined && window.editing == undefined){
            console.log('all false')
            form.style.display='none'
            document.comment_form.style.display='block';
        } else if (window.company == undefined && window.editing == true){
            console.log('editing true')
            form.style.display='none'
            document.comment_form.style.display='block';
        }
    })
}
submitThirdStep()
function commentSubmit(){

    // form.addEventListener('submit',(e)=>{
    //     e.preventDefault();
    //
    // })
}
commentSubmit();
function commentSubmitFunction(){
        let newData,
        com_forms = [
            document.firstForm,
            document.commercial_second_form,
            document.commercial_third_section,
            document.comment_form
        ],
        res_forms = [
            document.firstForm,
            document.residential_second_form,
            document.residential_third_section,
            document.comment_form,
        ];
    if (window.editing == true || window.editing == undefined){
        if (firstFormData.type == 'commercial'){
            com_forms.forEach(el => {
                newData = {...newData,...Object.fromEntries(new FormData(el).entries())}
            })
        } else if (firstFormData.type == 'residential'){
            res_forms.forEach(el => {
                newData = {...newData,...Object.fromEntries(new FormData(el).entries())}
            })
        }
        console.log(newData)
        let formData = {
            action : 'mailer',
            nonce: mainVars.nonce,
            data: JSON.stringify(newData)
        };
        formData = getFormData(formData);
        console.log(formData)


        fetch( mainVars.ajax_url, {
            method: 'POST',
            body: formData,
        } )
            .then( res => res.text() )
            .then( data => console.log(data))
            .catch( err => console.log( err,data) );
    }
}
function hideEditingBlock(){
    var block = document.querySelector('.edit_box');



        block.classList.remove('active_div')


}

function addEditingBlock(){
    let prevButtons = document.querySelectorAll('editing_prev');





    prevButtons.forEach(button =>{
        button.addEventListener('click',()=>{
            if (window.editing == undefined){
                block.classList.add('active_div')
            }
        })
    })
}