
window.addEventListener('load',()=>{
    var company,typeOfCompany,requestOk,firstFormData,setMinMaxDate,wo_dates_suggestions,observer,editing = false;
    lookOnMutation()
    catchOrganization();
    editAllInputs()
    hideRadioLogic()
})

function catchOrganization()
{
    let form = document.firstForm;
        form.addEventListener('submit',(e)=>{
            e.preventDefault()
            // doRequestFromFirstForm(form)

        })

}
function inputExeptions(){
    const  inputsNotRequired = document.querySelectorAll('input:not([required])');
    return inputsNotRequired
}
function secondStep (data){
    isRequestNotEmpty(data) ? requestNotEmpty(data) : requestEmpty()
}
function requestNotEmpty(data){
    company = data.data
    hideSuccessBlocks()
    isCommercial() ? doCommercialThings() : doResidentialThings()
    editInputsInit()
}
function  requestEmpty (){
    isCommercial() ? doCommercialThingsWithNoData() : doResidentialThingsWithNoData()
}

// secondForm = document.both_second_section,
//     startThirdSectionSelect = document.querySelector('#both_second_section button#next'),
//     firstContactKey = firstContact((result.data.contacts)),
//     thirdForm;
// console.log(result)
// result = result.data;
// secondForm.style.display='block';
// secondForm.CID.value = result.company_id;
// secondForm.second_name.value = result.contacts[firstContactKey].last_name;
// secondForm.first_name.value = result.contacts[firstContactKey].first_name;
// secondForm.CNN.value = result.ccn;
//
// secondForm.phone.value = result.company_phone_numbers[0].value;
// secondForm.email.value = result.contacts[firstContactKey].email;
function doCommercialThingsWithNoData(){
    document.firstForm.style.display ='none';
    document.commercial_second_form.style.display = 'block';
}
function doResidentialThingsWithNoData(){
    document.firstForm.style.display ='none';
    document.residential_second_form.style.display = 'block';
}
function doResidentialThings(){
    hideFirstForm()
    parseResidentialInputs()
}
function parseResidentialInputs (){
    let secondForm = document.residential_second_form;
    hideRadioLogic()
    parseFormAdresses(secondForm);
    parseFormContact(secondForm);
    disableInputs(document.residential_second_form)
    parseFourthSection()
}
function doCommercialThings(){
        document.commercial_second_form.style.display = 'block',
        document.firstForm.style.display ='none';
    disableInputs(document.commercial_second_form)
    parseFormContact(document.commercial_second_form);
    let startThirdSectionSelect = document.querySelector('#commercial_second_form button#next'),
        secondForm = document.commercial_second_form,
        thirdForm = isCommercial ? document.commercial_third_section
                                : document.residential_third_section;

    startThirdSectionSelect.addEventListener('click',()=>{
        if (window.company != undefined){
            thirdForm.company_name.value = company.company_name
            thirdForm.address.value = company.addresses.site?.address_line1
                ?? company.addresses.bill?.address_line1
                ?? company.addresses.mail?.address_line1
            thirdForm.address_line.value = company.addresses.site?.address_line2
                ?? company.addresses.bill?.address_line2
                ?? company.addresses.mail?.address_line2
            thirdForm.zip.value = company.addresses.site?.postal_code
                ?? company.addresses.bill?.postal_code
                ?? company.addresses.mail?.postal_code
            thirdForm.city.value = company.addresses.site?.locality
                ?? company.addresses.bill?.locality
                ?? company.addresses.mail?.locality
            isCompanyHaveOneAdress ? thirdForm.mailing_billing.value = 'yes'
                : thirdForm.mailing_billing.value = 'no'
            isCompanyHaveOneAdress ? hideMailingBillingDivs : parseMailingBilling

            secondForm.style.display='none';
            thirdForm.style.display='block';
            //  data.data.device_table.forEach(device => {
            //      var opt = document.createElement('option');
            //      opt.value = device.model;
            //      opt.innerHTML = device.application + ' model: ' +device.model + ' serial: ' + device.serial + ' size: ' + device.size;
            //      select.appendChild(opt);
            // });
            disableInputs(thirdForm);
        }
    })
        
}
// function sendRequestForJobToken(){
//     let formData = {
//         action : 'jobtoken',
//         nonce: mainVars.nonce,
//         CID : 1030783  ,
//         email : 'contact-2@ma.co',
//         wo_date: '',
//         date_start: '',
//         date_end: '',
//     };
//     formData = getFormData(formData);
//
//     fetch( mainVars.ajax_url, {
//         method: 'POST',
//         body: formData,
//     } )
//         .then( res => res.text() )
//         .then( data => jobTokenCookie(JSON.parse(data)))
//         .catch( err => console.log( err,data) );
//
// }
function jobTokenCookie(data){
    console.log(data)
    if (data.success == true){
        let result = JSON.parse(data.data)
        console.log(result);
        if (result.result == 'success'){
            let name = "jobtoken";
            let value = result.job_token;
            document.cookie = encodeURIComponent(name) + '=' + encodeURIComponent(value);
            console.log(document.cookie);
            sendToken();
        }
    } else {
        console.log('cant set cookie')
        console.log(data)
    }

}
function getCookie(name) {

    var matches = document.cookie.match(new RegExp(
        "(?:^|; )" + name.replace(/([\.$?*|{}\(\)\[\]\\\/\+^])/g, '\\$1') + "=([^;]*)"
    ))
    return matches ? decodeURIComponent(matches[1]) : undefined
}
function  sendToken(){

        let formDataJson = {
            action : 'getdatessuggestions',
            nonce: mainVars.nonce,
            token : getCookie('jobtoken'),
        };

    formData = getFormData(formDataJson);

    fetch( mainVars.ajax_url, {
        method: 'POST',
        body: formData,
    } )
        .then( res => res.text() )
        .then( (data,formData) => {doValidationSuggestions(JSON.parse(data),formData)})
        // .then( data => console.log(JSON.parse(data),funcformDataJson))
        .catch( err => console.log( err,data) );
}

function doValidationSuggestions(data){
    if (data.data.status == 'done'){
            wo_dates_suggestions = data.data.data.wo_dates_suggestions
            parseFifthSection(wo_dates_suggestions)

    } else {
        setTimeout(()=>{
            sendToken()
        }, 1500)
    }
}
// sendToken()
function isCommercial (){
    return (firstFormData.type == 'commercial') ?  true : false
}
function isCompanyHaveOneAdress (){
    return (company.addresses.mail == company.addresses.mail) ? true : false
}
function isRequestNotEmpty(data){
    console.log(data.data)
    return data.data == undefined ? false : true
}
function isApiRequestSuccess(){

}
function hideMailingBillingDivs(){

}
function parseMailingBilling(form){
    form.bill_mail_state.value = company.addresses.bill?.administrative_area
        ?? company.addresses.mail?.administrative_area
    form.bill_mail_address.value = company.addresses.bill?.address_line1
        ?? company.addresses.mail?.address_line1
    form.bill_mail_address_line.value = company.addresses.bill?.address_line2
        ?? company.addresses.mail?.address_line2
    form.bill_mail_zip.value = company.addresses.bill?.postal_code
        ?? company.addresses.mail?.postal_code
    form.bill_mail_city.value = company.addresses.bill?.locality
        ?? company.addresses.mail?.locality
}
function parseBillingAndMailling(form){

}
function doRequestFromFirstForm(form){
    let addtoformdata = {
        action : 'ajaxgetorgdata',
        nonce: mainVars.nonce
        },
        data = Object.fromEntries(new FormData(form).entries()),
        finalResult;
        console.log(data)
        firstFormData = data;
        Object.assign(data,addtoformdata);
        finalResult = getFormData(data);
        fetch( mainVars.ajax_url, {
            method: 'POST',
            body: finalResult,
        } )
            .then( res => res.text())
            // .then( data => console.log(JSON.parse(data)))
            .then( data => secondStep(JSON.parse(data)))
            .catch( err => console.log( err,data) );

        // form.style.display='none'

}
function getFormData(object) {

    const formData = new FormData();
    Object.keys(object).forEach(key => formData.append(key, object[key]));
    return formData;
}
function firstContact (obj){

    return Object.keys(obj)[0];
}
function hideSuccessBlocks(){

    // document.querySelectorAll('.hide-if-success').forEach(el => {
    //     el.style.display='none';
    // })
}

function hideFirstForm(){
    let secondForm = document.residential_second_form,
        firstForm = document.firstForm;
        firstForm.style.display='none';
        secondForm.style.display='block';
}
function parseFormAdresses(form){
    form.state.value = company.addresses.site?.administrative_area
                    ?? company.addresses.bill?.administrative_area
                    ?? company.addresses.mail?.administrative_area
    form.address.value = company.addresses.site?.address_line1
                    ?? company.addresses.bill?.address_line1
                    ?? company.addresses.mail?.address_line1
    form.address_line.value = company.addresses.site?.address_line2
                    ?? company.addresses.bill?.address_line2
                    ?? company.addresses.mail?.address_line2
    form.zip.value = company.addresses.site?.postal_code
                    ?? company.addresses.bill?.postal_code
                    ?? company.addresses.mail?.postal_code
    form.city.value = company.addresses.site?.locality
                    ?? company.addresses.bill?.locality
                    ?? company.addresses.mail?.locality
    isCompanyHaveOneAdress() ? form.mailing_billing.value = 'yes'
                            : form.mailing_billing.value = 'no'
    if (form.mailing_billing.value == 'yes'){
        form.mailing_billing.forEach(el => {

            if (el.value == form.mailing_billing.value){
                let changeEvent = new Event('change');
                el.dispatchEvent(changeEvent);
            }
        })
    }
    isCompanyHaveOneAdress() ? hideMailingBillingDivs : parseBillingAndMailling(form)
}

function parseFormContact (form){
    let firstContactKey = firstContact((company.contacts));
    form.CID.value = company.company_id;
    form.CCN.value = company.ccn;
    form.second_name.value = company.contacts[firstContactKey].last_name;
    form.first_name.value = company.contacts[firstContactKey].first_name;
    form.CCN.value = company.ccn;
    form.phone.value = company.company_phone_numbers[0].value;
    form.email.value = company.contacts[firstContactKey].email;
    form.phone_type.value = company.company_phone_numbers[0].type == '' ? 'other' : company.company_phone_numbers[0].type;
    if (form.phone_type.value == 'other'){
        form.phone_type.forEach(el => {
            if (el.value == form.phone_type.value){
                let changeEvent = new Event('change');
                el.dispatchEvent(changeEvent);
            }
        })
        form.other.value = company.company_phone_numbers[0].ext

    }
}


function dontHideElementFromRadio(radios,value,el,inputs = undefined){
    radios.forEach(radio =>{
        radio.addEventListener('change',(e)=>{
            if (radio.value == value)
            {
                el.classList.remove('hide')
                inputs.forEach(input=>{
                    requireInput(input,true)
                })
            }
            else
            {
                el.classList.add('hide')
                    inputs.forEach(input=>{
                        requireInput(input,false)
                    })
            }
        })
    })

}

function requireInput(input,boolean){

        if(input.dataset.required == 'false') {
            input.required = false
        } else{
            input.required = boolean
        }


}
function isInNodelist(node,nodelist){
    Array.from(nodelist).some(el =>{
        el == node
    })
}
function hideRadioLogic (){
    let showLogic = [
        {
                'radio_type' : 'phone_type',
                'value'      : 'other',
                'input'      : 'phone_type',
                'div'        : 'phone_type'
        },
        {
                'radio_type' : 'mailing_billing',
                'value'      : 'no',
                'input'      : 'mailing_billing_group',
                'div'        : 'mailing_billing'
        },
        {
            'radio_type' : 'phone_type_c',
            'value'      : 'other',
            'input'      : 'other_group_c',
            'div'        : 'phone_group_c'
        },
        {
            'radio_type' : 'contact_update',
            'value'      : 'NO',
            'input'      : 'contact_update',
            'div'        : 'contact_update'
        },
        {
            'radio_type' : 'mailing_billing_c',
            'value'      : 'no',
            'input'      : 'mailing_billing_c',
            'div'        : 'mailing_billing_c'
        },
        {
            'radio_type' : 'third_party',
            'value'      : 'yes',
            'input'      : 'third_party',
            'div'        : 'third_party'
        },
        {
            'radio_type' : 'adress_is',
            'value'      : 'rental',
            'input'      : 'rental',
            'div'        : 'rental'
        },
        {
            'radio_type' : 'adress_is',
            'value'      : 'vacant',
            'input'      : 'vacant',
            'div'        : 'vacant'
        },
        {
            'radio_type' : 'contact_site',
            'value'      : 'lockbox',
            'input'      : 'contact_site',
            'div'        : 'contact_site'
        },
        {
            'radio_type' : 'site_contact',
            'value'      : 'no',
            'input'      : 'site_contact',
            'div'        : 'site_contact'
        },
        {
            'radio_type' : 'gated',
            'value'      : 'yes',
            'input'      : 'gated',
            'div'        : 'gated'
        },
        {
            'radio_type' : 'rental_radio',
            'value'      : 'rental',
            'input'      : 'rental_radio',
            'div'        : 'rental_radio'
        },
        {
            'radio_type' : 'rental_radio',
            'value'      : 'vacant',
            'input'      : 'vacant_radio',
            'div'        : 'vacant_radio'
        },
        {
            'radio_type' : 'lockbox_radio',
            'value'      : 'lockbox',
            'input'      : 'lockbox_access',
            'div'        : 'lockbox_access'
        },
        {
            'radio_type' : 'inside_radio',
            'value'      : 'outside',
            'input'      : 'inside_location',
            'div'        : 'inside_location'
        },
        {
            'radio_type' : 'sprinklers_type',
            'value'      : 'yes',
            'input'      : 'sprinklers_inputs',
            'div'        : 'sprinklers_group'
        }

    ];
    for (var obj in showLogic) {
            dontHideElementFromRadio(document.querySelectorAll(`[data-radio^=${showLogic[obj].radio_type}]`), showLogic[obj].value,
                document.querySelector(`[data-group^=${showLogic[obj].div}]`),
                document.querySelectorAll(`[data-el^=${showLogic[obj].input}]`))
    }

}
function disableInputs(form,arg = true){
    let inputs = form.elements;
    for (const input of inputs) {
        if (input.tagName == 'INPUT' && input.type != 'date' || input.tagName == 'SELECT'  ){
            input.disabled = arg;
        }
    }
}
function ableInputs(form){
    let inputs = form.elements;
    for (const input of inputs) {
        if (input.tagName == 'INPUT' && input.type != 'date' || input.tagName == 'SELECT' ){
            input.disabled = false;
        }
    }
}
function thirdstep(){
    let secondForm = document.residential_second_form,
        thirdForm = document.residential_third_section;
    secondForm.addEventListener("submit",(e)=>{
        e.preventDefault();
        secondForm.style.display = 'none';
        thirdForm.style.display = 'block';
    })
}
thirdstep()
function sendDateForSprinklers (){
    let form = document.residential_third_section;

    form.addEventListener('submit',(e)=>{
        e.preventDefault()
       // console.log(form.turned_on.value)
        if (window.company != undefined){
            sendCompanyDataForToken(form);
            residentialFourthStep()
        }
    })
    // sendCompanyDataForToken(form)
}
function sendCompanyDataForToken(form){

        let formData = {
            action : 'jobtoken',
            nonce: mainVars.nonce,
            CID : firstFormData.CID,
            email : firstFormData.email,
            // wo_date: '',
            date_start: form.turned_on.value != '' ? formatDate(new Date(form.turned_on.value)) : ''
            // date_end: form.turned_on.value != '' ? '31-10-'+ new Date().getFullYear() : '',
        };
          console.log(formData)
        formData = getFormData(formData);

        fetch( mainVars.ajax_url, {
            method: 'POST',
            body: formData,
        } )
            .then( res => res.text() )
            .then( data => jobTokenCookie(JSON.parse(data)))
            .catch( err => console.log( err,data) );

}
sendDateForSprinklers();


function formatDate(date) {
    let month = date.getMonth()+1
    month = (month < 10) ? '0'+ month : month

    return date.getDate() + "-" + month + "-" + date.getFullYear()
}

function formatDateForDateInputs(date){
    let month = date.getMonth()+1
    month = (month < 10) ? '0'+ month : month

    return date.getFullYear() + "-" + month + "-" + date.getDate()
}
function setMinMaxDate(){
    let residentionalForm = document.residential_third_section,
        thisYear = new Date().getFullYear(),
        minDate = new Date (thisYear,3,15),
        maxDate = new Date (thisYear,9,31);
        residentionalForm.turned_on.setAttribute('max',formatDateForDateInputs(maxDate))
        residentionalForm.turned_on.setAttribute('min',formatDateForDateInputs(minDate))
}
setMinMaxDate()



function parseFourthSection(){
    let feesTable = document.getElementById('fees_table'),
        deviceTable = document.getElementById('device_table');
        feesTable.innerHTML = `<tr><td>Device fee:</td><td>${company.fees.device_fee}</td></tr>`
        feesTable.innerHTML = feesTable.innerHTML + `<tr><td>Second fee:</td><td>${company.fees.second_fee}</td></tr>`
        feesTable.innerHTML = feesTable.innerHTML + `<tr><td>Village fee:</td><td>${company.fees.village_fee}</td></tr>`
        feesTable.innerHTML = feesTable.innerHTML + `<tr><td>Total fee:</td><td>${ company.fees.total_fee}</td></tr>`

        deviceTable.innerHTML = `<tr><th>Model</th><th>Serial</th><th>Size</th><th>Location</th></tr>`
        company.device_table.forEach(device => {
            deviceTable.innerHTML = deviceTable.innerHTML + `<tr><td>${device.model}</td><td>${device.serial}</td><td>${device.size}</td><td>${device.location}</td></tr>`
        });
}
function parseFifthSection(wo_dates_suggestions = undefined){
    let suggestionsblock = document.querySelector('.suggestions');
    console.log(wo_dates_suggestions)
    wo_dates_suggestions.forEach((el,index) =>{
        if (index == 0){
            suggestionsblock.innerHTML =`<input type="radio" id='suggestions_date${index}'
               name="suggestions_date" value="${el}">
               <label data-show="show" for='suggestions_date${index}'>
            ${el}</label>`
        } else {
            suggestionsblock.innerHTML = suggestionsblock.innerHTML +`<input type="radio" id='suggestions_date${index}'
               name="suggestions_date" value="${el}">
               <label for='suggestions_date${index}'>
            ${el}</label>`
        }

    })
    datePicked()
    suggestionsShow()
}

function backBtnLogic (){
    let residentionalLogic = [document.firstForm, document.residential_second_form,document.residential_third_section,document.fourthForm,document.fifth_form],
        commercialLogic = [],
        key,
        backbuttons = document.querySelectorAll(`[data-button^=prev]`)
    ;
    backbuttons.forEach(btn =>{
        btn.addEventListener('click',()=>{
            if (firstFormData.type == 'residential'){
               key = findKeyOfArray(residentionalLogic,btn.closest('form'))
                residentionalLogic[key].style.display ='none'
               residentionalLogic[key-1].style.display ='block'
            }

        })
    })
}
backBtnLogic()

function findKeyOfArray (arr,key) {
    return arr.indexOf(key)
}
function residentialFourthStep (){
    document.residential_third_section.style.display ='none'
    document.fourthForm.style.display ='block'
    document.fourthForm.addEventListener('submit',(e)=>{
        e.preventDefault()
    })
}
function datePicked (){
    let form = document.fifth_form,
        radio = form.suggestions_date;
    form.addEventListener('submit',(e)=>{
        e.preventDefault()
            let firstContactKey = firstContact((company.contacts)),formData = {
                action : 'createjob',
                nonce: mainVars.nonce,
                CID :  firstFormData.CID ,
                email : firstFormData.email,
                date : radio.value,
                first_name: company.contacts[firstContactKey].first_name,
                last_name: company.contacts[firstContactKey].last_name,
    };
    console.log(formData)
    formData = getFormData(formData);

    fetch( mainVars.ajax_url, {
        method: 'POST',
        body: formData,
    } )
        .then( res => res.text() )
        .then( data => successDiv(JSON.parse(data)))
        .catch( err => console.log( err,data) );
        })


    }
function successDiv (a){
    console.log();
    let six_success = document.querySelector(".success");

    if (a.data.result=='success'){
        document.fifth_form.style.display='none';
        six_success.style.display='block';
    } else {
        alert(a)
    }

}
function lookOnMutation () {
    var target = document.querySelector('.suggestions');

    const config = {
        childList: true,
    };
    const callback = function(mutationsList, observer) {
        for (let mutation of mutationsList) {
            if (mutation.type === 'childList') {



            }
        }
    };
  observer = new MutationObserver(callback);

// Начинаем наблюдение за настроенными изменениями целевого элемента
    observer.observe(target, config);
}

function suggestionsShow(){
    console.log('suggestionsShow')
    let sug = document.querySelectorAll('.suggestions label'),
        nextBtn = document.querySelector('#nextDate'),
        arraySug= Array.from(sug);
    observer.disconnect();
    nextBtn.addEventListener('click',(e)=>{
        firstElement = arraySug.find(elementIsNotDisplay)
        if (firstElement != undefined ){
            firstElement.setAttribute("data-show", "show")
        } else {
            nextBtn.style.display = 'none'
        }
    })
}
function elementIsNotDisplay(a){
    try{
        if ( a.getAttribute('data-show') == null) {

            return a;
        }
    } catch (e) {
        console.log(e)
    }
}
function openfifthStep () {
    let  submitBtn = document.querySelector('#fourthForm button[type=submit]');
    document.fourthForm.addEventListener('submit',(e)=>{
        e.preventDefault();
        console.log(submitBtn);
        if (wo_dates_suggestions != undefined){
            document.fourthForm.style.display = 'none';
            document.fifth_form.style.display = 'block';
        }
    })

}
openfifthStep()

function openFourthStep (){
    let form = document.commercial_third_section;
    form.addEventListener('submit',(e)=>{
        if (window.company != undefined){
            e.preventDefault();
            sendCompanyDataForToken(form)
            parseFourthSection()
            form.style.display='none';
            document.fourthForm.style.display ='block'
            sendToken()
        }

    })
}
openFourthStep();
function commercialJobToken (){

}
function editInputsInit (){
    let div = document.querySelector('.edit_box');
    div.classList.add('active_div')
}
function editAllInputs(){
    let div = document.querySelector('.edit_box');
    div.addEventListener('click',()=>{
        editingAll(div)
    })
}
function editingAll(div){
    div.classList.add('editing');
    editing = true;
    window.company = undefined;
    console.log('editing :', editing)
    disableInputs(document.commercial_second_form,false)
    disableInputs(document.residential_second_form,false)
    disableInputs(document.commercial_third_section,false)
    disableInputs(document.residential_third_section,false)
    let hidenElements = document.querySelectorAll('.hide-if-success');
    hidenElements.forEach(elem => {
        elem.classList.remove('hide-if-success')
    })
    fullnameEvents()
}

