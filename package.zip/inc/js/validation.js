
window.addEventListener('load',()=>{
    validate()
})
function validate(){
        jQuery.validator.addMethod("emailValidation", function(value, element) {
            return this.optional( element ) || /^(([^<>()[\]\.,;:\s@\"]+(\.[^<>()[\]\.,;:\s@\"]+)*)|(\".+\"))@(([^<>()[\]\.,;:\s@\"]+\.)+[^<>()[\]\.,;:\s@\"]{2,})$/i.test( value );
        },'Please enter a valid email address.')
        $("#firstForm").validate({
        rules:{
            CID:{
                required: true,
                number: true
            },
            email:{
                required: true,
                emailValidation:true
            }
        },
        submitHandler: function(form) {
            if ($("#firstForm").valid()){
                window.doRequestFromFirstForm(form)
            }
        }
    });
    $("#commercial_second_form").validate({
        rules:{
            CID: {
                required: true,
                number: true
            },
            first_name: {
                required: true,
                minlength: 2
            },
            second_name: {
                required: true,
                minlength: 2
            },
            email: {
                required: true,
                emailValidation:true
            },
            phone: {
                required:true,
                digits:true
            },
            other:{
                required: true,
                minlength: 2
            },
            site_last_name:{
                required: true,
                minlength: 2
            },
            site_first_name:{
                required: true,
                minlength: 2
            },
            site_phone:{
                required:true,
                digits:true
            },
            site_email:{
                required:true,
                emailValidation:true
            },
            phone_type_c:{
                required:true
            }

        },
        submitHandler: function(form) {
            if ($("#commercial_second_form").valid()){

            }
        }
    });
    $("#commercial_third_section").validate({
        rules:{
            company_name:{
                required: true,
                minlength: 2
            },
            email:{
                required: true,
                emailValidation:true
            },
            address:{
                required: true,
                minlength: 2
            },
            address_line:{
                required: true,
                minlength: 2
            },
            zip:{
                required: true,
                minlength: 6
            },
            billing_attention:{
                required: true,
                minlength: 2
            },
            billing_address:{
                required: true,
                minlength: 2
            },
            billing_city:{
                required: true,
                minlength: 2
            },
            billing_zip:{
                required: true,
                minlength: 6
            },
            mailing_attention:{
                required: true,
                minlength: 2
            },
            mailing_address:{
                required: true,
                minlength: 2
            },
            mailing_zip: {
                required: true,
                minlength: 6
            },
            rental_first_name: {
                required: true,
                minlength: 2
            },
            rental_last_name: {
                required: true,
                minlength: 2
            },
            rental_phone:{
                required: true,
                digits: true
            },
            rental_email:{
                required: true,
                emailValidation: true
            },
            lockbox_location: {
                required: true,
                minlength: 3
            },
            lockbox_code:{
                required: true,
                minlength: 2
            },
            phone_type:{
                required: true
            },

        },
        submitHandler: function(form) {
            if ($("#commercial_third_section").valid()){
                window.hideEditingBlock()
            }
        }
    });

    //
    $("#residential_second_form").validate({
        rules:{
            CID: {
                required: true,
                digits: true
            },
            CCN:{
                required: true,
                minlength: 2
            },
            first_name:{
                required: true,
                minlength: 2
            },
            second_name:{
                required: true,
                minlength: 2
            },
            email:{
                required: true,
                emailValidation: true
            },
            phone:{
                required: true,
                digits:true
            },
            phone_type:{
                required: true
            },
            other:{
                required:true
            },
            address:{
                required:true,
                minlength:2
            },
            address_line:{
                required:true,
                minlength:2
            },
            zip:{
                required:true,
                minlength:6
            },
            bill_mail_name:{
                required:true,
                minlength:2
            },
            bill_mail_address:{
                required:true,
                minlength:2
            },
            bill_mail_address_line:{
                required:true,
                minlength:2
            },
            bill_mail_zip:{
                required:true,
                minlength:6
            },
            site_choice:{
                required:true,
            },
            site_contact_first:{
                required:true,
                minlength:2
            },
            site_contact_last:{
                required:true,
                minlength:2
            },
            site_contact_phone:{
                required:true,
                digits:true
            },
            site_contact_email:{
                required:true,
                emailValidation: true
            }
        },
        submitHandler: function(form) {
            if ($("#residential_second_form").valid()){
            }
        }

    });

     $("#residential_third_section").validate({
         rules:{
            gated:{
                required:true,
            },
             gated_text:{
                 required:true,
             },
             adress_type:{
                 required:true,
             },
             rental_first_name:{
                 required:true,
                 minlength:2
             },
             rental_last_name:{
                 required:true,
                 minlength:2
             },
             rental_phone:{
                 required:true,
                 digits:true
             },
             rental_email:{
                 required:true,
                 emailValidation:true
             },
             lockbox_radio:{
                 required:true,
             },
             lockbox_location:{
                 required:true,
             },
             lockbox_code:{
                 required:true,
             },
             inside_radio:{
                 required:true,
             },
             turned_on:{
                 required:true,
             }
         }, submitHandler: function(form) {
             if ($("#residential_second_form").valid()){
                 window.hideEditingBlock()
             }
         }
     });

    $("#comment_form").validate({
        rules:{
            comment:{
                required:true
            }
        }, submitHandler: function(form) {
            if ($("#fourthForm").valid()){
                window.commentSubmitFunction()
            }
        }

    });
}